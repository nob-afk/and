import random
print('This is a free Project by Jonathan B. licenced under the MIT License. [jonathanb.de]')

randomint = random.randint(1, 999999)
if randomint <= 9:
	randomint = '0' + str(randomint)
print(str(randomint) + random.choice(['-abdnwj-bcjwwa-xnfrea', '-brnsam-bsjfsa-bfnrwa', '-mdbrea-btrwqa-nfneas']))

print("done! have fun!")
input()
