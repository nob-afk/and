Hello.

the tool isnt working anymore, Nvidia fixed it.
This tool is here for generating Geforce now codes.
Just download the python script and run it. 

[Python must be installed]

Contact me:
@JonathanDOTexe (twitter)
me [at] jonathanb [dot] de
